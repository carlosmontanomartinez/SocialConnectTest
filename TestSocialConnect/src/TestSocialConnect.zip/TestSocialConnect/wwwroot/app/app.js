﻿var app = angular.module("CinepolisApp",[]);


